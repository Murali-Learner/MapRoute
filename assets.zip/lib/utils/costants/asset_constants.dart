class AssetConstants {
  static String startIcon = 'assets/images/start_icon.png';
  static String endIcon = 'assets/images/end_icon.png';
  static String customIcon = 'assets/images/custom_icon.png';
  static String liveLocationIcon = 'assets/images/live_location_icon.png';
}
