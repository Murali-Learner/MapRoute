package com.example.map_route_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
